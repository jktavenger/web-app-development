.body{
    background-color: #4b0000;
    display:flex;
    justify-content: center;
    align-items: center;
    height:100vh;
    font:14px sans-serif;
}
*{
	box-sizing: border-box;
}
h2{
	text-align:center;
	margin-bottom:40px;
}
form{
    background-color: #cacaca;
    border: 2px solid #4b0000;
    border-radius: 20px;
    width: 500px;
    padding:30px;
}
label{
    color:#000000;
}
.inputbox{
    display: block;
    border: 2px solid #ccc;
    width:95%;
    padding: 10px;
    margin:10px auto;
    border-radius:5px;
}
 .wrap{
  width: 350px; 
  padding: 20px; 
}
.submit{
    float: right;
    background: #003190;
    padding:10px 15px;
    color:#fff;
    border-radius:5px;
    margin-right:10px;
    border:none;
}
.submit:hover{
    opacity:.7;
}
.reset{
    float: right;
    background: grey;
    padding:10px 15px;
    border-radius:5px;
    margin-right:10px;
    border:none;
}
.reset:hover{
    opacity:.7;
}
.error{
    background:#F2DEDE;
    color:#A94442;
    padding:10px;
    width:95%;
    border-radius:5px;
}
.logout{
    float: left;
    background: rgb(0,255,0);
    padding:10px 15px;
    color:#fff;
    border-radius:5px;
    margin-right:10px;
    border:none;
}