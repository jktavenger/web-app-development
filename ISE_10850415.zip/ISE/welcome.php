<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	 <a href="logout.php" class= "logout">Log Out</a><br><br>
	 <h1>HELLO USER, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. WELCOME TO OUR SITE.</h1>
</body>
</html>